#target photoshop
app.displayDialogs=DialogModes.NO;
var target='C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_apn_bellas_final.psd',d=null;
for(var i=0;i<app.documents.length;i++)if(app.documents[i].fullName.fsName.replace(/\\/g,'/').toLowerCase()==target.toLowerCase())d=app.documents[i];
if(!d)d=app.open(new File(target));app.activeDocument=d;
var old=[];for(var i=0;i<d.layers.length;i++)old.push(d.layers[i].visible);
function sd(x){return stringIDToTypeID(x)}function cd(x){return charIDToTypeID(x)}
var changed=[];
function change(l){
 if(l.typename=='LayerSet'){for(var i=0;i<l.layers.length;i++)change(l.layers[i]);return}
 if(l.kind!=LayerKind.TEXT)return;
 var ref=new ActionReference();ref.putIdentifier(cd('Lyr '),l.id);
 var td=executeActionGet(ref).getObjectValue(sd('textKey'));
 var ranges=td.getList(sd('textStyleRange')),newRanges=new ActionList(),hit=false;
 for(var i=0;i<ranges.count;i++){
  var r=ranges.getObjectValue(i),st=r.getObjectValue(sd('textStyle'));
  if(st.hasKey(sd('color'))){
   var c=st.getObjectValue(sd('color')),red=c.getDouble(sd('red')),green=c.getDouble(sd('green')),blue=c.getDouble(sd('blue'));
   var oldDark=Math.abs(red-113)<2&&Math.abs(green-59)<2&&Math.abs(blue-83)<2;
   var oldMauve=Math.abs(red-164)<2&&Math.abs(green-113)<2&&Math.abs(blue-136)<2;
   if(oldDark||oldMauve){
    var nc=new ActionDescriptor();nc.putDouble(sd('red'),179);nc.putDouble(sd('green'),113);nc.putDouble(sd('blue'),142);
    st.putObject(sd('color'),sd('RGBColor'),nc);r.putObject(sd('textStyle'),sd('textStyle'),st);hit=true;
   }
  }
  newRanges.putObject(sd('textStyleRange'),r);
 }
 if(hit){td.putList(sd('textStyleRange'),newRanges);var set=new ActionDescriptor(),rr=new ActionReference();rr.putIdentifier(cd('Lyr '),l.id);set.putReference(cd('null'),rr);set.putObject(cd('T   '),cd('TxLr'),td);executeAction(cd('setd'),set,DialogModes.NO);changed.push(l.name)}
}
for(var i=0;i<d.layerSets.length;i++)change(d.layerSets[i]);
for(var n=1;n<=12;n++){
 if(n!=1&&n!=2&&n!=4&&n!=6&&n!=9)continue;
 var g=null,p=('0'+n).slice(-2);for(var i=0;i<d.layerSets.length;i++)if(d.layerSets[i].name.indexOf(p)==0)g=d.layerSets[i];
 for(var i=0;i<d.layers.length;i++)d.layers[i].visible=(d.layers[i]==g||d.layers[i].name=='Plano de Fundo');
 var f=new File('C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_provas/pagina_'+p+'.jpg'),o=new JPEGSaveOptions();o.quality=12;d.saveAs(f,o,true,Extension.LOWERCASE);
}
var f=new File('C:/Users/Murilo/Documents/Codex/2026-10-14/tes/work/support_color_log.txt');f.open('w');f.write(changed.join('\n'));f.close();
for(var i=0;i<d.layers.length;i++)d.layers[i].visible=old[i];d.save();
'OK '+changed.length;
