from pathlib import Path
import json
import zipfile

import pymupdf
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parent.parent
proofs = [root / "optima_provas" / f"pagina_{n:02d}.jpg" for n in range(1, 13)]
for proof in proofs:
    with Image.open(proof) as image:
        assert image.size == (1920, 1080), proof

pdf = pymupdf.open()
for proof in proofs:
    page = pdf.new_page(width=1920, height=1080)
    page.insert_image(page.rect, filename=str(proof))
pdf.save(root / "optima_apn_bellas_final.pdf", garbage=4, deflate=True)
pdf.close()

sheet = Image.new("RGB", (1940, 4 * 390 + 20), "#f5f2f2")
draw = ImageDraw.Draw(sheet)
for i, proof in enumerate(proofs):
    with Image.open(proof) as src:
        thumb = src.resize((620, 349), Image.Resampling.LANCZOS)
    x = 20 + (i % 3) * 640
    y = 20 + (i // 3) * 390
    sheet.paste(thumb, (x, y + 22))
    draw.text((x + 4, y + 2), f"PÁGINA {i+1:02d}", fill="#713B53")
sheet.save(root / "optima_visao_geral.jpg", quality=92, subsampling=0)

manifest_path = root / "optima_manifest_final.json"
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
manifest["photos"] = {
    "4": "optima_assets/foto_04_espresso_v3.png",
    "5": "optima_assets/foto_05_modelo_real_margens_final.png",
    "6": "optima_assets/foto_06_proporcao_real_creme.png",
    "7": "optima_assets/foto_07_proporcao_real_espresso.png",
    "12": "optima_assets/foto_12_hidratacao_espresso.png",
}
manifest["identity"]["dark_ink"] = "#B3718E"
manifest["notes"] = [
    "O PSD preserva as alterações manuais feitas no Photoshop.",
    "Títulos principais unidos em uma camada de texto, com destaques internos editáveis.",
    "Cartões da página 12 alinhados ao primeiro cartão ajustado manualmente.",
    "Imagens de produto criadas como fotografias integrais usando a proporção real enviada.",
    "Cor de apoio #B3718E aplicada aos destaques escuros sobre páginas claras.",
    "Página 12 recebeu uma cena de hidratação com foto distinta das poses de axila.",
]
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

readme = root / "optima_codigo" / "LEIA-ME.txt"
readme.write_text(
    "APN Optima Bellas\n\n"
    "O arquivo PSD é o documento final editável e inclui ajustes manuais feitos no Photoshop.\n"
    "Os scripts desta pasta são incrementais para fotos, títulos, cartões e exportação.\n"
    "O PDF e as provas foram gerados a partir do PSD atual.\n",
    encoding="utf-8",
)
current_scripts = [
    "add_photo_05.jsx", "replace_photo_04.jsx", "replace_photo_06.jsx",
    "replace_photo_07.jsx", "merge_titles_final.jsx", "align_cards12_final.jsx",
    "export_all_pages.jsx", "empacotar_atual.py", "LEIA-ME.txt",
    "add_photo_12.jsx", "support_color_final.jsx",
]
with zipfile.ZipFile(root / "optima_codigo.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for name in current_scripts:
        path = root / "optima_codigo" / name
        archive.write(path, f"optima_codigo/{name}")

with pymupdf.open(root / "optima_apn_bellas_final.pdf") as check:
    assert len(check) == 12
    assert all(page.rect.width == 1920 and page.rect.height == 1080 for page in check)

print("PDF, contact sheet, manifest and code ZIP updated")
