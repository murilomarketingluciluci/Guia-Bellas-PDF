#target photoshop
app.displayDialogs=DialogModes.NO;
var target='C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_apn_bellas_final.psd';
var d=null;
for(var i=0;i<app.documents.length;i++)if(app.documents[i].fullName.fsName.replace(/\\/g,'/').toLowerCase()==target.toLowerCase())d=app.documents[i];
if(!d)d=app.open(new File(target));app.activeDocument=d;
var oldVisibility=[];for(var vi=0;vi<d.layers.length;vi++)oldVisibility.push(d.layers[vi].visible);
function sd(x){return stringIDToTypeID(x)}function cd(x){return charIDToTypeID(x)}
function td(id){var r=new ActionReference();r.putIdentifier(cd('Lyr '),id);return executeActionGet(r).getObjectValue(sd('textKey'))}
function merge(a,b,multiline){
 var t1=a.textItem.contents,t2=b.textItem.contents,sep=multiline?'\r':'',merged=t1+sep+t2,A=td(a.id),B=td(b.id);
 var s1=A.getList(sd('textStyleRange')).getObjectValue(0).getObjectValue(sd('textStyle'));
 var s2=B.getList(sd('textStyleRange')).getObjectValue(0).getObjectValue(sd('textStyle'));
 var rr=new ActionList(),r1=new ActionDescriptor(),r2=new ActionDescriptor(),cut=t1.length+sep.length;
 r1.putInteger(sd('from'),0);r1.putInteger(sd('to'),cut);r1.putObject(sd('textStyle'),sd('textStyle'),s1);rr.putObject(sd('textStyleRange'),r1);
 r2.putInteger(sd('from'),cut);r2.putInteger(sd('to'),merged.length);r2.putObject(sd('textStyle'),sd('textStyle'),s2);rr.putObject(sd('textStyleRange'),r2);
 A.putString(sd('textKey'),merged);A.putList(sd('textStyleRange'),rr);
 var pr=A.getList(sd('paragraphStyleRange')).getObjectValue(0);pr.putInteger(sd('from'),0);pr.putInteger(sd('to'),merged.length);var pl=new ActionList();pl.putObject(sd('paragraphStyleRange'),pr);A.putList(sd('paragraphStyleRange'),pl);
 var set=new ActionDescriptor(),ref=new ActionReference();ref.putIdentifier(cd('Lyr '),a.id);set.putReference(cd('null'),ref);set.putObject(cd('T   '),cd('TxLr'),A);executeAction(cd('setd'),set,DialogModes.NO);
 b.remove();a.name=merged.replace(/\r/g,' ');return merged;
}
var cfg={1:['Desodorante',true],2:['Alum',false],3:['O que',false],4:['O que',false],8:['\u00d3leo de ',false],9:['Pele hidratada',true],10:['Tempo de',false],11:['Por que esse processo',true]};
var logs=[];
for(var key in cfg){
 var num=parseInt(key),g=null,c=null;
 for(var i=0;i<d.layerSets.length;i++)if(d.layerSets[i].name.indexOf(('0'+num).slice(-2))==0)g=d.layerSets[i];
 for(var j=0;j<g.layerSets.length;j++)if(g.layerSets[j].name=='CONTENT')c=g.layerSets[j];
 var a=null,b=null,limit=num==1?540:(num==9?280:290);
 for(var k=0;k<c.artLayers.length;k++){
  var l=c.artLayers[k];if(l.kind!=LayerKind.TEXT||l.bounds[1].as('px')>=limit)continue;
  if(l.textItem.contents.indexOf(cfg[key][0])==0)a=l;else b=l;
 }
 if(!a||!b)throw Error('Title layers missing '+key+' a='+a+' b='+b);
 logs.push(key+' '+merge(a,b,cfg[key][1]));
 for(var h=0;h<d.layers.length;h++)d.layers[h].visible=(d.layers[h]==g||d.layers[h].name=='Plano de Fundo');
 var f=new File('C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_provas/pagina_'+('0'+num).slice(-2)+'.jpg'),o=new JPEGSaveOptions();o.quality=11;d.saveAs(f,o,true,Extension.LOWERCASE);
}
var lf=new File('C:/Users/Murilo/Documents/Codex/2026-10-14/tes/work/merge_title_log.txt');lf.open('w');lf.write(logs.join('\n'));lf.close();
for(var vi=0;vi<d.layers.length;vi++)d.layers[vi].visible=oldVisibility[vi];d.save();
'OK merged titles';
