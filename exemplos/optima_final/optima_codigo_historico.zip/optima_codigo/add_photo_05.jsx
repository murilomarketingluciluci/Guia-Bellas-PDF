#target photoshop
app.displayDialogs=DialogModes.NO;
var target='C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_apn_bellas_final.psd';
var source='C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_assets/foto_05_modelo_real_margens_final.png';
var d=null;
for(var i=0;i<app.documents.length;i++)if(app.documents[i].fullName.fsName.replace(/\\/g,'/').toLowerCase()==target.toLowerCase())d=app.documents[i];
if(!d)d=app.open(new File(target));
app.activeDocument=d;
var g=null,base=null,brand=null;
for(var i=0;i<d.layerSets.length;i++)if(d.layerSets[i].name.indexOf('05')==0)g=d.layerSets[i];
if(!g)throw Error('Página 05 não encontrada');
for(var i=g.artLayers.length-1;i>=0;i--){
 var l=g.artLayers[i];
 if(l.name=='FOTO 05 | retrato editorial')l.remove();
 else if(l.name.indexOf('BG copiar 2')==0)base=l;
 else if(l.name.indexOf('Camada 2 copiar 2')==0)brand=l;
}
if(!base)throw Error('Fundo 05 não encontrado');
var src=app.open(new File(source)),w=800,h=1080;
var sw=src.width.as('px'),sh=src.height.as('px'),scale=Math.max(w/sw,h/sh);
src.resizeImage(UnitValue(Math.ceil(sw*scale),'px'),UnitValue(Math.ceil(sh*scale),'px'),null,ResampleMethod.BICUBIC);
var rw=src.width.as('px'),rh=src.height.as('px'),cx=(rw-w)/2,cy=(rh-h)/2;
src.crop([UnitValue(cx,'px'),UnitValue(cy,'px'),UnitValue(cx+w,'px'),UnitValue(cy+h,'px')]);
src.selection.selectAll();src.selection.copy();
app.activeDocument=d;d.activeLayer=base;
var fresh=d.paste();fresh.name='FOTO 05 | retrato editorial';
fresh.move(base,ElementPlacement.PLACEBEFORE);
fresh.translate(UnitValue(-fresh.bounds[0].as('px'),'px'),UnitValue(-fresh.bounds[1].as('px'),'px'));
fresh.visible=true;if(brand)brand.visible=true;
app.activeDocument=src;src.close(SaveOptions.DONOTSAVECHANGES);
app.activeDocument=d;
for(var i=0;i<d.layers.length;i++)d.layers[i].visible=(d.layers[i]==g||d.layers[i].name=='Plano de Fundo');
d.save();
var f=new File('C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_provas/pagina_05.jpg'),o=new JPEGSaveOptions();o.quality=11;
d.saveAs(f,o,true,Extension.LOWERCASE);
'OK foto 05';



