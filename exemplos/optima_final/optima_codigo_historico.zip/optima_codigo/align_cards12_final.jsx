#target photoshop
app.displayDialogs=DialogModes.NO;
var target='C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_apn_bellas_final.psd',d=null;
for(var i=0;i<app.documents.length;i++)if(app.documents[i].fullName.fsName.replace(/\\/g,'/').toLowerCase()==target.toLowerCase())d=app.documents[i];
if(!d)d=app.open(new File(target));app.activeDocument=d;
var old=[];for(var i=0;i<d.layers.length;i++)old.push(d.layers[i].visible);
function ink(hex){var c=new SolidColor();c.rgb.hexValue=hex;return c}
var g=null,c=null;for(var i=0;i<d.layerSets.length;i++)if(d.layerSets[i].name.indexOf('12')==0)g=d.layerSets[i];
for(var i=0;i<g.layerSets.length;i++)if(g.layerSets[i].name=='CONTENT')c=g.layerSets[i];
var specs=[
 ['REPASSE',985,372,780,78,40],
 ['USE HIDRATANTES',145,557,750,78,38],
 ['BEBA ALOE',985,557,780,78,40],
 ['USE PRODUTOS',145,750,750,120,85],
 ['VITAMINA C',985,750,780,120,85]
];
for(var q=0;q<specs.length;q++){
 var s=specs[q],t=null,icon=null,card=null;
 for(var i=0;i<c.artLayers.length;i++){
  var l=c.artLayers[i];if(l.kind==LayerKind.TEXT&&l.textItem.contents.indexOf(s[0])==0){t=l;icon=c.artLayers[i+1];card=c.artLayers[i+2];break;}
 }
 if(!t||!icon||!card)throw Error('Missing '+s[0]);
 d.activeLayer=card;d.selection.selectAll();d.selection.clear();
 d.selection.select([[s[1],s[2]],[s[1]+s[3],s[2]],[s[1]+s[3],s[2]+s[4]],[s[1],s[2]+s[4]]]);d.selection.fill(ink('A9708A'));d.selection.deselect();
 var ib=icon.bounds,ic=(ib[1].as('px')+ib[3].as('px'))/2,cy=s[2]+s[4]/2;icon.translate(UnitValue(0,'px'),UnitValue(cy-ic,'px'));
 t.textItem.width=UnitValue(s[3]-130,'px');t.textItem.height=UnitValue(s[5],'px');
 var tb=t.bounds,tx=tb[0].as('px'),tc=(tb[1].as('px')+tb[3].as('px'))/2;t.translate(UnitValue(s[1]+97-tx,'px'),UnitValue(cy-tc,'px'));
}
for(var i=0;i<d.layers.length;i++)d.layers[i].visible=(d.layers[i]==g||d.layers[i].name=='Plano de Fundo');
var f=new File('C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_provas/pagina_12.jpg'),o=new JPEGSaveOptions();o.quality=12;d.saveAs(f,o,true,Extension.LOWERCASE);
for(var i=0;i<d.layers.length;i++)d.layers[i].visible=old[i];d.save();
'OK cards final';
