#target photoshop
app.displayDialogs=DialogModes.NO;
var target="C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_apn_bellas_final.psd", image="C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_assets/foto_06_proporcao_real_creme.png", proofs="C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_provas";
var number=6, x=0, y=0, w=700, h=1080;
var d=null;
for(var i=0;i<app.documents.length;i++) if(app.documents[i].fullName.fsName.replace(/\\/g,'/').toLowerCase()==target.toLowerCase()) d=app.documents[i];
if(!d) d=app.open(new File(target));
app.activeDocument=d;
var prefix=('0'+number).slice(-2), group=null;
for(var i=0;i<d.layerSets.length;i++) if(d.layerSets[i].name.indexOf(prefix)==0) group=d.layerSets[i];
if(!group) throw Error('Grupo nao encontrado '+prefix);
var old=null;
for(var i=group.artLayers.length-1;i>=0;i--){
 var l=group.artLayers[i];
 if(l.name.indexOf('FOTO '+prefix+' | fundo neutro')==0 || l.name.indexOf('FRASCO '+prefix+' | original')==0 || l.name=='Contraste suave da assinatura') l.remove();
 else if(l.name.indexOf('FOTO '+prefix+' | substituir imagem')==0) old=l;
}
if(!old) throw Error('Camada de foto nao encontrada '+prefix);
var src=app.open(new File(image));
var sw=src.width.as('px'),sh=src.height.as('px'),scale=Math.max(w/sw,h/sh);
src.resizeImage(UnitValue(Math.ceil(sw*scale),'px'),UnitValue(Math.ceil(sh*scale),'px'),null,ResampleMethod.BICUBIC);
var rw=src.width.as('px'),rh=src.height.as('px'),cx=(rw-w)/2,cy=(rh-h)/2;
src.crop([UnitValue(cx,'px'),UnitValue(cy,'px'),UnitValue(cx+w,'px'),UnitValue(cy+h,'px')]);
src.selection.selectAll();src.selection.copy();
app.activeDocument=d;d.activeLayer=old;
var fresh=d.paste();fresh.name='FOTO '+prefix+' | fundo neutro final';
fresh.move(old,ElementPlacement.PLACEBEFORE);
var left=fresh.bounds[0].as('px'),top=fresh.bounds[1].as('px');
fresh.translate(UnitValue(x-left,'px'),UnitValue(y-top,'px'));
old.visible=false;fresh.visible=true;
app.activeDocument=src;src.close(SaveOptions.DONOTSAVECHANGES);
app.activeDocument=d;
for(var i=0;i<d.layers.length;i++) d.layers[i].visible=(d.layers[i]==group||d.layers[i].name=='Plano de Fundo');
d.save();
var f=new File(proofs+'/pagina_'+prefix+'.jpg'),o=new JPEGSaveOptions();o.quality=11;d.saveAs(f,o,true,Extension.LOWERCASE);
'OK foto '+prefix+' '+fresh.bounds[0].as('px')+','+fresh.bounds[1].as('px')+','+fresh.bounds[2].as('px')+','+fresh.bounds[3].as('px');

