#target photoshop
app.displayDialogs=DialogModes.NO;
var target='C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_apn_bellas_final.psd';
var d=null;
for(var i=0;i<app.documents.length;i++)if(app.documents[i].fullName.fsName.replace(/\\/g,'/').toLowerCase()==target.toLowerCase())d=app.documents[i];
if(!d)d=app.open(new File(target));app.activeDocument=d;
var old=[];for(var i=0;i<d.layers.length;i++)old.push(d.layers[i].visible);
var out='C:/Users/Murilo/Documents/Codex/2026-10-14/tes/outputs/optima_provas';
for(var n=1;n<=12;n++){
 var prefix=('0'+n).slice(-2),g=null;
 for(var k=0;k<d.layerSets.length;k++)if(d.layerSets[k].name.indexOf(prefix)==0)g=d.layerSets[k];
 if(!g)throw Error('Page '+prefix+' missing');
 for(var i=0;i<d.layers.length;i++)d.layers[i].visible=(d.layers[i]==g||d.layers[i].name=='Plano de Fundo');
 var f=new File(out+'/pagina_'+prefix+'.jpg'),o=new JPEGSaveOptions();o.quality=12;d.saveAs(f,o,true,Extension.LOWERCASE);
}
for(var i=0;i<d.layers.length;i++)d.layers[i].visible=old[i];
d.save();
'OK 12 pages';
